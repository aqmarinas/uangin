<?php
session_start();
require 'koneksi.php';



$nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : '';
?>
