<?php
    include('koneksi.php');

    $tgl_pengeluaran = $_GET['tgl_pengeluaran'];
    $jumlah = $_GET['jumlah'];
    $sumber = $_GET['sumber'];

    // Query Update
    $query = mysqli_query($koneksi,"INSERT INTO `pengeluaran` (`tgl_pengeluaran`, `jumlah`, `id_sumber`) VALUES ('$tgl_pengeluaran', '$jumlah', '$sumber')");

    if ($query) {
        # Redirect ke page index.php
        header("location:pengeluaran.php"); 
    } else{
        echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
    }
?>